#include "userprog/syscall.h"
#include <stdio.h>
#include <stddef.h>
#include <syscall-nr.h>
#include "threads/interrupt.h"
#include "threads/thread.h"
#include <user/syscall.h>
#include "devices/input.h"
#include "devices/shutdown.h"
#include "filesys/file.h"
#include "filesys/filesys.h"
#include "threads/malloc.h"
#include "threads/synch.h"
#include "threads/vaddr.h"
#include "userprog/pagedir.h"
#include "userprog/process.h"
#include "vm/frame.h"
#include "vm/page.h"
#include "vm/swap.h"
#define VADDR_BOTTOM ((void *) 0x08048000)
#define MAX_ARGS 3
static void syscall_handler (struct intr_frame *);
void check_address(void*);
void check_buffer(void * buffer, unsigned size,void*esp,bool to_write);
struct family* find_family(int pid);
void unpin_ptr (void* vaddr);
void unpin_string (void* str);
void unpin_buffer (void* buffer, unsigned size);
void get_arg (struct intr_frame *f, int *arg, int n);
void check_valid_buffer (void* buffer, unsigned size, void* esp,	bool to_write);
void check_valid_string (const void* str, void* esp);
struct sup_page_entry* check_valid_ptr (const void *vaddr, void* esp); //add

	void
syscall_init (void) 
{
	lock_init(&filesys_lock);
	intr_register_int (0x30, 3, INTR_ON, syscall_handler, "syscall");
}

	static void
syscall_handler (struct intr_frame *f UNUSED) 
{
//	uint32_t *esp = f ->esp; 
//	check_address(esp);
	//check_valid_ptr((const void*) f->esp, f->esp);
//	int syscall_num = *esp++;
	int arg[MAX_ARGS];
	check_valid_ptr((const void*)f->esp, f->esp);
	switch(*(int *)f->esp)
	{
	case  SYS_HALT :                   /* Halt the operating system. */
	{
		halt();
		break;
	}
	case  SYS_EXIT :                  /* Terminate this process. */
	{
//		check_address(esp);
//		int status = (int)*(esp)++; 
//		exit(status);
		get_arg(f, &arg[0], 1);
		exit(arg[0]);
		break;
	}
	case  SYS_EXEC :                   /* Start another process. */
	{
//		check_address(esp);
//		char *cmd_line = (char *)*(esp)++;
//		char* ptr = pagedir_get_page(thread_current()->pagedir, cmd_line);
//		if(!ptr) exit(-1);
//		cmd_line = ptr;
//		f->eax = exec(cmd_line);	
//		unpin_string((void*)cmd_line);//add
		get_arg(f, &arg[0], 1);
		check_valid_string((const void *)arg[0], f->esp);
		f->eax = exec((const char *) arg[0]);
		unpin_string((void *) arg[0]);
		break;
	}
	case  SYS_WAIT :                   /* Wait for a child process to die. */
	{
	//	check_address(esp);
	//	pid_t pid = (int)*(esp)++;
	//	f->eax = wait(pid);
		get_arg(f, &arg[0], 1);
		f->eax = wait(arg[0]);
		break;
	}
	case SYS_CREATE :                 /* Create a file. */
	{
//		check_address(esp);
//		char *file_name = (char*)*(esp)++;
//		check_address(esp);
//		unsigned initial_size = (unsigned)*(esp)++;
//		char* ptr = pagedir_get_page(thread_current()->pagedir, file_name);
//		if(!ptr) exit(-1);
//		file_name = ptr;
//		f->eax = create(file_name, initial_size);
//	unpin_string((void*)file_name);
	get_arg(f, &arg[0], 2);
		check_valid_string((const void *) arg[0], f->esp);
			f->eax = create((const char *)arg[0], (unsigned) arg[1]);
				unpin_string((void *) arg[0]);	
		break;
	}

	case SYS_REMOVE :                /* Delete a file. */
	{
//		check_address(esp);
//		char *file_name = (char*)*(esp)++;
//		char* ptr = pagedir_get_page(thread_current()->pagedir, file_name);
//		if(!ptr) exit(-1);
//		file_name = ptr;
//		f->eax = remove(file_name);rg(f, &arg[0], 1);
get_arg(f,&arg[0],1);
	check_valid_string((const void *) arg[0], f->esp);
		f->eax = remove((const char *) arg[0]);	
		
		break;
	}

	case SYS_OPEN :               /* Open a file. */
	{
//		check_address(esp);
//		char *file_name = (char*)*(esp)++;
//		struct thread* t = thread_current();
//		char* ptr = pagedir_get_page(t->pagedir, file_name);
//		if(!ptr) exit(-1);
//		file_name = ptr;
//		f->eax = open(file_name); 
//	unpin_string((void*)file_name);
	get_arg(f, &arg[0], 1);
		check_valid_string((const void *) arg[0], f->esp);
			f->eax = open((const char *) arg[0]);
				unpin_string((void *) arg[0]);
		break;
	}
	case SYS_FILESIZE :              /* Obtain a file's size. */
	{
//		check_address(esp);
//		int fd = (int)*(esp)++;
//		f->eax = filesize(fd);
	get_arg(f, &arg[0], 1);
		f->eax = filesize(arg[0]);
		break;
	}
	case SYS_READ :                  /* Read from a file. */
	{
//		check_address(esp);
//		int fd = (int)*(esp)++;
//		check_address(esp);
//		char *buffer = (char *)*(esp)++;
//		check_address(esp);
//		unsigned size = (unsigned)*(esp)++;
//		struct thread* t = thread_current();
///		uint32_t *pd = t->pagedir;
//		check_buffer((void *) buffer, size, f->esp, true);	
//		char* ptr = pagedir_get_page(t->pagedir, buffer);
//		if(!ptr) exit(-1);
//		buffer = ptr;
//		f->eax = read(fd,buffer,size);
	//	unpin_buffer((void*)buffer,(unsigned)size);
	get_arg(f, &arg[0], 3);
		check_valid_buffer((void *) arg[1], (unsigned) arg[2], f->esp,
					   true);
			f->eax = read(arg[0], (void *) arg[1], (unsigned) arg[2]);
				unpin_buffer((void *) arg[1], (unsigned) arg[2]);
		break;
	}
	case SYS_WRITE :                 /* Write to a file. */
	{
//		check_address(esp);
//		int fd = (int)*(esp)++;
//		check_address(esp);
//		char *buffer = (char *)*(esp)++;
//		check_address(esp);
//		unsigned size = (unsigned)*(esp)++;
//		struct thread* t = thread_current();
///		uint32_t *pd = t->pagedir;
//		check_buffer((void *) buffer, size, f->esp, false);	
//		
//		char* ptr = pagedir_get_page(t->pagedir, buffer);
//		if(!ptr) exit(-1);
//		buffer = ptr;
//		f->eax = write(fd,buffer,size);
//	unpin_buffer((void*)buffer,(unsigned)size);
	get_arg(f, &arg[0], 3);
		check_valid_buffer((void *) arg[1], (unsigned) arg[2], f->esp,
					   false);
			f->eax = write(arg[0], (const void *) arg[1],
					       (unsigned) arg[2]);
				unpin_buffer((void *) arg[1], (unsigned) arg[2]);
		break;
	}
	case SYS_SEEK :                  /* Change position in a file. */
	{
//		check_address(esp);
//		int fd = (int)*(esp)++;
//		check_address(esp);
//		unsigned position =(unsigned)*(esp)++;
//		seek(fd,position);
	get_arg(f, &arg[0], 2);
		seek(arg[0], (unsigned) arg[1]);
		break;
	}
	case SYS_TELL :                  /* Report current position in a file. */
	{
//		check_address(esp);
//		int fd = (int)*(esp)++;
//		f->eax = tell(fd);
	get_arg(f, &arg[0], 1);
		f->eax = tell(arg[0]);
		break;
	}
	case SYS_CLOSE :                 /* Close a file. */
	{
//		check_address(esp);
//		int fd = (int)*(esp)++;
//		close(fd);
	get_arg(f, &arg[0], 1);
		close(arg[0]);
		break;
	}
    case SYS_MMAP:
    {
//		check_address(esp);
//		int fd = (int)*(esp)++;
//		check_address(esp);	
//		void *addr = (void*)(esp)++;
//		f->eax = mmap(fd, addr);
	get_arg(f, &arg[0], 2);
		f->eax = mmap(arg[0], (void *) arg[1]);
		break;
    }
    case SYS_MUNMAP:
    {
//		check_address(esp);
//		int mapping = (int)*(esp)++;
//		munmap(mapping);
	get_arg(f, &arg[0], 1);
		munmap(arg[0]);
		break;
    }
	unpin_ptr(f->esp);
	default:
	NOT_REACHED();
	break;
	}
}

//add

void get_arg (struct intr_frame *f, int *arg, int n)
{
  int i;
  int *ptr;
  for (i = 0; i < n; i++)
    {
      ptr = (int *) f->esp + i + 1;
      check_valid_ptr((const void *) ptr, f->esp);
      arg[i] = *ptr;
    }
}


int mmap (int fd, void *addr)
{
	struct thread *cur = thread_current();
	struct file *old_file = cur->fd_array[fd];
  if (!old_file || !is_user_vaddr(addr) || addr < USER_VADDR_BOTTOM ||
      ((uint32_t) addr % PGSIZE) != 0)
    {
      return -1;
	}
  struct file *file = file_reopen(old_file);
  if (!file || file_length(old_file) == 0)
    {
      return -1;
    }
  thread_current()->mapid++;
  int32_t ofs = 0;
  uint32_t read_bytes = file_length(file);
  while (read_bytes > 0)
    {
      uint32_t page_read_bytes = read_bytes < PGSIZE ? read_bytes : PGSIZE;
      uint32_t page_zero_bytes = PGSIZE - page_read_bytes;
      if (!add_mmap_to_page_table(file, ofs,
				  addr, page_read_bytes, page_zero_bytes))
	{
	  munmap(thread_current()->mapid);
	  return -1;
	}
      read_bytes -= page_read_bytes;
      ofs += page_read_bytes;
      addr += PGSIZE;
  }
  return thread_current()->mapid;
}

void munmap (int mapping)
{
  process_remove_mmap(mapping);
}


void halt(void)
{
	shutdown_power_off();
}

void exit(int status)
{
	struct thread* t = thread_current();
	printf("%s: exit(%d)\n",t->name, status) ;
	awake_waiter(status);
	thread_exit();
}

pid_t exec(char* cmd_line)
{
	pid_t pid;
	pid = process_execute(cmd_line);
	struct family *f = find_family(pid);
	if (!f) {
		return -1;
	}
	while(f->load == 0){
		barrier();
	}
	if (f->load == 2){
		 return -1;
	}
	return pid;
}

struct family* find_family(int pid)
{
	struct list_elem *e;
	struct family *f;
	for(e = list_begin(&family_list); e!= list_end(&family_list);e=list_next(e))
	{
		f = list_entry(e, struct family, elem);
		if(f->c_tid == pid)
			return f;
	}
	return NULL;
}

int wait(pid_t pid)
{
	int status = process_wait(pid);
	return status; 
}

bool create(char *file, unsigned initial_size)
{
	if(file == NULL)
		exit(-1);
	lock_acquire(&filesys_lock);
	bool success = filesys_create(file, initial_size);
	lock_release(&filesys_lock);
	return success;
}

bool remove( char *file)
{
	if(file == NULL)
		exit(-1);
	lock_acquire(&filesys_lock);
	bool success = filesys_remove(file);
	lock_release(&filesys_lock);
	return success;
}

int open(char *file)
{
	if(file == NULL) 
		exit(-1);
	struct thread *cur = thread_current();
	int i;
	lock_acquire(&filesys_lock);
	for( i = 2; i<128 ; i++)
	{
		if(cur -> fd_array[i] == NULL)
		{	cur->fd_array[i] = filesys_open(file);	
			if(file == NULL || cur->fd_array[i] == NULL)
			{	
	lock_release(&filesys_lock);
				return -1;
			}
			else { 
	lock_release(&filesys_lock);
				return i; 
			}
		}
	}
	lock_release(&filesys_lock);
	return -1;

}

int filesize(int fd)
{
	if(fd < 2 || fd > 128) 
		exit(-1);
	struct thread *t = thread_current();
	if(t->fd_array[fd] == NULL)
		exit(-1);
	lock_acquire(&filesys_lock);
	int Len = file_length(t->fd_array[fd]);
	lock_release(&filesys_lock);
	return Len;
}

int read(int fd, char* buffer, unsigned size)
{
	
	if ( fd == 0)
	{	
		unsigned count = 0;
		while(1)
		{
		uint8_t k = input_getc();
		if(k == 13)
		{
			buffer[count] = '\0';
			break;
		}
		else 
			buffer[count++] = k;
		if(count >= size)
			break;
		}
		return size;
	}
	else if(fd >= 2 && fd <= 128)
	{
	lock_acquire(&filesys_lock);
		struct thread *cur = thread_current();
		struct file *f = cur->fd_array[fd];
		if(f == NULL){
		lock_release(&filesys_lock);
			return -1;
		}
		else{
			int bytes = file_read(f, buffer, size);
			lock_release(&filesys_lock);
			 return bytes;
			}
	}
	else{
		return -1;
	}
}

int write(int fd, char* buffer, unsigned size)
{
	if ( fd == 1)
	{	
		putbuf(buffer, size);
		return size;	
	}
	else if(fd >= 2 && fd <=128)
	{
	lock_acquire(&filesys_lock);
		struct thread* cur = thread_current();
		struct file *f = cur->fd_array[fd];
		if(f == NULL)
		{
	lock_release(&filesys_lock);
			return -1;
		}
		else{
			int bytes = file_write(f, buffer, size);
	lock_release(&filesys_lock);
			return bytes;
		}
	}
	else{
		return -1;
	}
}

void seek(int fd, unsigned position)
{
	if(fd < 2 || fd > 128) exit(-1);
	struct thread *t = thread_current();
	if(t->fd_array[fd] == NULL)
		exit(-1);
	lock_acquire(&filesys_lock);
	file_seek(t->fd_array[fd], position);
	lock_release(&filesys_lock);
}

unsigned tell(int fd)
{
	if(fd < 2 || fd >128) exit(-1);
	struct thread *t = thread_current();
	if(t->fd_array[fd] == NULL)
		exit(-1);
	lock_acquire(&filesys_lock);
	unsigned Tell = file_tell(t->fd_array[fd]);
	lock_release(&filesys_lock);
	return Tell;
}

void close(int fd)
{
	if(fd > 128 || fd < 2){
		exit(-1);
	}
	struct thread *t = thread_current();
	if(t->fd_array[fd] == NULL){
		exit(-1);
	}
	lock_acquire(&filesys_lock);
	file_close(t->fd_array[fd]);
	t -> fd_array[fd] = NULL;
	free(t->fd_array[fd]);
	lock_release(&filesys_lock);
}

void check_address(void* address)
{
	struct thread *t = thread_current();
	uint32_t *pd = t -> pagedir;
	if(address < VADDR_BOTTOM || !is_user_vaddr(address))
		exit(-1);
	if(pagedir_get_page(pd,address)==NULL)
		exit(-1);
}

void check_buffer(void * buffer, unsigned size, void*esp, bool to_write)
{
	unsigned i;
	char* buffer2 = (char *)buffer;
	for(i = 0;i< size; i++)
	{
	//add
//     struct sup_page_entry *spte = check_valid_ptr((const void*)
//					    buffer2, esp);
 //    if (spte && to_write)
//	{
//	  if (!spte->writable)
//	    {
//	      exit(-1);
//	    }
//	}
		check_address((void *) buffer2);
		buffer2++;
	}
}


struct sup_page_entry* check_valid_ptr(const void *vaddr, void* esp)
{
  if (!is_user_vaddr(vaddr) || vaddr < USER_VADDR_BOTTOM)
    {
      exit(-1);
    }
  bool load = false;
 struct sup_page_entry *spte = get_spte((void *)vaddr);
  if (spte)
    {
      load_page(spte);
      load = spte->is_loaded;
    }
  else if (vaddr >= esp - STACK_HEURISTIC)
    {
      load = grow_stack((void *) vaddr);
    }
  if (!load)
    {
      exit(-1);
    }
  return spte;
}

void check_valid_buffer (void* buffer, unsigned size, void* esp,	bool to_write)
{
	unsigned i;
	char* local_buffer = (char *) buffer;
	for (i = 0; i < size; i++)
	{
		struct sup_page_entry *spte = check_valid_ptr((const void*)
				local_buffer, esp);
		if (spte && to_write)
		{
			if (!spte->writable)
			{
				exit(-1);
			}
		}
		local_buffer++;
	}
}

void check_valid_string (const void* str, void* esp)
{
	check_valid_ptr(str, esp);
	while (* (char *) str != 0)
	{
		str = (char *) str + 1;
		check_valid_ptr(str, esp);
	}
}

void unpin_ptr (void* vaddr)
{
  struct sup_page_entry *spte = get_spte(vaddr);
  if (spte)
    {
      spte->pinned = false;
    }
}

void unpin_string (void* str)
{
  unpin_ptr(str);
  while (* (char *) str != 0)
    {
      str = (char *) str + 1;
      unpin_ptr(str);
    }
}

void unpin_buffer (void* buffer, unsigned size)
{
  unsigned i;
  char* local_buffer = (char *) buffer;
  for (i = 0; i < size; i++)
    {
      unpin_ptr(local_buffer);
      local_buffer++;
    }
}
