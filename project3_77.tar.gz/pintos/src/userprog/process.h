#ifndef USERPROG_PROCESS_H
#define USERPROG_PROCESS_H

#include "threads/thread.h"

#include "vm/frame.h"
#include "vm/page.h"
#include "vm/swap.h"
struct family
{
	tid_t p_tid;
	tid_t c_tid;
	struct list_elem elem;
	int load;
	bool wait;
	int status;
};
struct waiter
{
	tid_t c_tid;
	struct thread* t;
	int status;
	struct list_elem elem;
	bool exit;
};
struct mmap_file {
  struct sup_page_entry *spte;
  int mapid;
  struct list_elem elem;
};
tid_t process_execute (const char *file_name);
int process_wait (tid_t);
void process_exit (void);
void process_activate (void);
void awake_waiter (int status);
bool install_page (void *upage, void *kpage, bool writable);
bool process_add_mmap (struct sup_page_entry *spte);
void process_remove_mmap (int mapping);
#endif /* userprog/process.h */
